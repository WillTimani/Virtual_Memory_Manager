
/*=====================================Operating System=======================================*/

#include <ProcessControlBlock.hpp>

pageTableEntry ProcessControlBlock::myPageTable[PAGE_SIZE];
